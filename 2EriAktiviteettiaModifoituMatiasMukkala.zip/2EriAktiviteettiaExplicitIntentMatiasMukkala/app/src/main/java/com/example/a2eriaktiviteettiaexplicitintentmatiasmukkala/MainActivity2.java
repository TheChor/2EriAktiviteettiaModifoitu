package com.example.a2eriaktiviteettiaexplicitintentmatiasmukkala;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.RatingBar;

public class MainActivity2 extends AppCompatActivity {

    private RatingBar ratingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        ratingBar = (RatingBar) findViewById(R.id.ratingBar);
        ratingBar.setNumStars(5);
        ratingBar.setStepSize(1);
        ratingBar.setRating(2);
    }

    public void btn_link_1 (View view) {
        goToUrl ( "https://www.lapinkansa.fi/");
    }

    public void btn_link_2 (View view) {
        goToUrl ( "https://www.iltalehti.fi/");
    }

    public void btn_link_3 (View view) {
        goToUrl ( "https://www.is.fi/");
    }

    public void btn_link_4 (View view) {
        goToUrl ( "https://yle.fi/uutiset");
    }

    private void goToUrl (String url) {
        Uri uriUrl = Uri.parse(url);
        Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl);
        startActivity(launchBrowser);
    }

    public void homeScreen(View view) {
        Intent i = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(i);
    }
}